//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by bidi.rc
//
#define IDD_BIDI						144
#define IDC_INPUT						4189
#define IDC_EX_LEVEL					4190
#define IDC_DISPL						4191
#define IDC_TYPES						4192
#define IDC_N_TYPES 					4193
#define IDC_IM_LEVEL					4194
#define IDC_W_TYPES 					4195
#define IDC_RLE 						4196
#define IDC_LRE 						4197
#define IDC_RLO 						4198
#define IDC_LRO 						4199
#define IDC_MIRROR						4200
#define IDC_RLM 						4201
#define IDC_IMPLICIT					4202
#define IDC_X_TYPES 					4203
#define IDC_LRM 						4204
#define IDC_CLEAN						4205
#define IDC_LS							4206

#define IDC_LEGEND						4216
#define IDC_BASELEVEL					4217

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         4218
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
