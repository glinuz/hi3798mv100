Bidi Reference Sample (C++)

This sample provides source code for a reference implementation of the
Unicode Bidi Algorithm defined in UAX#9 Unicode Bidirectional Algorithm
http://unicode.org/reports/tr9/

This code can be compiled in several ways
a) command line version
b) standalone Windows program
For more information see the comments in the file Bidi.cpp

Earlier versions of the code are maintained in subfolders, e.g. v25g
