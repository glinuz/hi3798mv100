cp os/linux/mt7601Usta.ko ../../../A20/A20/
cp os/linux/mt7601Usta.ko ../../../A20/A20/android4.2/device/softwinner/wing-k70/modules/modules/
rm os/linux/mt7601Usta.ko ../../../A20/A20/android4.2/out/target/product/wing-k70/system/vendor/modules/mt7601Usta.ko
