cp PREALLOC/os/linux/mtprealloc7601Usta.ko /proj/mtk05650/share/mt7601_softap/
cp os/linux/mt7601Usta.ko /proj/mtk05650/share/mt7601_softap/
