#ifndef __REGDB_H__
#define __REGDB_H__

extern const struct ieee80211_regdomain *reg_regdb[];
extern int reg_regdb_size;

#endif /* __REGDB_H__ */
