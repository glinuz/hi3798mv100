#!/bin/sh

if [ $# -ne 3 ]
then
    echo -e "usage: ./MakeCASystemRootBox.sh out_dir  mode toolchains_name"
    echo -e "        for example: ./MakeCASystemRootfs.sh /home/user/HiSTBLinuxV100R002/out/hi3716mv410/hi3716m41dma_ca_debug/rootbox DEBUG arm-histbv300-linux"
    exit 1
fi


rootbox_dir=$1
mode=$2
toolchain_name=$3
sdk_path=$1/../../../..
etc_dir=$sdk_path/source/rootfs/scripts/hica_build/none/system_build


STRIP=${toolchain_name}-strip

if [ -d $etc_dir ];then
   echo "$etc_dir" 
else
   echo "$etc_dir is not exist"
   exit 1 
fi

if [ -d $rootbox_dir ];then
   echo "$rootbox_dir" 
else
   echo "$rootbox_dir is not exist"
   exit 1
fi


SCP=cp
SRM=rm


$SCP -a $etc_dir/etc/*  $rootbox_dir/etc

$STRIP $rootbox_dir/bin/*
$STRIP $rootbox_dir/sbin/*
$STRIP $rootbox_dir/lib/*.so
$STRIP $rootbox_dir/usr/bin/*
$STRIP $rootbox_dir/usr/lib/*.so

$STRIP --strip-debug --strip-unneeded --remove-section=.comment --remove-section=.note --preserve-dates $rootbox_dir/kmod/usb/*.ko
$STRIP --strip-debug --strip-unneeded --remove-section=.comment --remove-section=.note --preserve-dates $rootbox_dir/kmod/*.ko
