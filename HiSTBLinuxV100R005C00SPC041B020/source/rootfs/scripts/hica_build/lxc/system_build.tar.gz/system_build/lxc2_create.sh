#!/bin/sh  

if [ $# -ne 2 ]
then
    echo -e "usage: ./lxc_creat.sh sdk_dir lxc_name"
    echo -e "        for example: ./lxc1_creat.sh /home/user/HiSTBLinuxV100R002/out/hi3716mv410/hi3716m41dma_ca_debug/rootbox stb2"
    exit 1
fi

SDK_PATH=$1/../../../..
PREFIX=$1
name=$2
SAMPLE_OUT_PATH=$1/../$OBJ_NAME/sample

APP_NAME=ipc_client_test
APP_NAME2=openssl_server_test
APP_RUN_CMD="./ipc_client_test &"
APP_RUN_CMD1="./openssl_server_test &"

# create fs directory tree
install_fs_dir()
{
	tree="\
$PREFIX/$lxc_rootfs_dir/dev \
$PREFIX/$lxc_rootfs_dir/home \
$PREFIX/$lxc_rootfs_dir/root \
$PREFIX/$lxc_rootfs_dir/etc \
$PREFIX/$lxc_rootfs_dir/etc/init.d \
$PREFIX/$lxc_rootfs_dir/bin \
$PREFIX/$lxc_rootfs_dir/sbin \
$PREFIX/$lxc_rootfs_dir/proc \
$PREFIX/$lxc_rootfs_dir/sys \
$PREFIX/$lxc_rootfs_dir/mnt \
$PREFIX/$lxc_rootfs_dir/tmp \
$PREFIX/$lxc_rootfs_dir/dev/pts \
$PREFIX/$lxc_rootfs_dir/lib \
$PREFIX/$lxc_rootfs_dir/usr/sbin \
$PREFIX/$lxc_rootfs_dir/usr/lib"

	mkdir -p $tree
        chmod 755 $tree

	mkdir -p $PREFIX/`dirname $lxc_config_file` 
}

# create container init script for CA debug
install_dbg_fs_scripts()
{
	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/inittab
::sysinit:/etc/init.d/rcS
tty1::respawn:/sbin/getty -L tty1 115200 vt100
EOF
	chmod 644 $PREFIX/$lxc_rootfs_dir/etc/inittab

	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/init.d/rcS
#!/bin/sh
cd /home
#$APP_RUN_CMD
$APP_RUN_CMD1
EOF
	chmod 744 $PREFIX/$lxc_rootfs_dir//etc/init.d/rcS

	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/passwd
root:x:0:0:root:/root:/bin/sh
EOF
	chmod 644 $PREFIX/$lxc_rootfs_dir/etc/passwd

	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/group
root:x:0:root
EOF
	chmod 644 $PREFIX/$lxc_rootfs_dir/etc/group

	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/shadow
$name:\$1\$eF8I65UL\$7FfdLFZEBw46GPpAOYcOQ/:0:0:99999:7:::
EOF
	chmod 640 $PREFIX/$lxc_rootfs_dir/etc/shadow

	# udhcpc scripts
	mkdir -p $PREFIX/$lxc_rootfs_dir/usr/share/udhcpc
	cp -r $PREFIX/usr/share/udhcpc/* $PREFIX/$lxc_rootfs_dir/usr/share/udhcpc

}


# create container init script for CA release
install_rel_fs_scripts()
{
	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/inittab
::sysinit:/etc/init.d/rcS
EOF
	chmod 644 $PREFIX/$lxc_rootfs_dir/etc/inittab

	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/init.d/rcS
#!/bin/sh
cd /home
#$APP_RUN_CMD
$APP_RUN_CMD1
EOF
	chmod 744 $PREFIX/$lxc_rootfs_dir/etc/init.d/rcS
	
	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/passwd
root:x:0:0:root:/root:/bin/sh
EOF
	chmod 644 $PREFIX/$lxc_rootfs_dir/etc/passwd

	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/group
root:x:0:root
EOF
	chmod 644 $PREFIX/$lxc_rootfs_dir/etc/group

	cat <<EOF > $PREFIX/$lxc_rootfs_dir/etc/shadow
$name:\$1\$eF8I65UL\$7FfdLFZEBw46GPpAOYcOQ/:0:0:99999:7:::
EOF
	chmod 640 $PREFIX/$lxc_rootfs_dir/etc/shadow

}

# install busybox 
install_busybox()
{
	# refer to  SDK cfg.mak (arm-hisiv200-linux_lxc_user.config) Busybox Config File For User 
	echo "refer to CFG_HI_BUSYBOX_CFG_USER_NAME"
	cp -rf $PREFIX/home/stb/* $PREFIX/$lxc_rootfs_dir/
	cp -rf $PREFIX/usr/sbin/init.lxc $PREFIX/$lxc_rootfs_dir/usr/sbin/
}

# install app 
install_app()
{
	# install our sample 
	echo "install our sample application: $APP_NAME $APP_NAME2"
	cp -fr $SAMPLE_OUT_PATH/lxc_ipc/$APP_NAME $PREFIX/$lxc_rootfs_dir/home/
	cp -fr $SAMPLE_OUT_PATH/openssl/server/$APP_NAME2 $PREFIX/$lxc_rootfs_dir/home/
	cp -fr $SAMPLE_OUT_PATH/openssl/key $PREFIX/$lxc_rootfs_dir/home/
	cat <<EOF > $PREFIX/$lxc_rootfs_dir/home/startup
#!/bin/sh
cd /home
$APP_RUN_CMD
$APP_RUN_CMD1
EOF

}

# create and deploy lxc config file for CA debug
install_lxc_dbg_config()
{
	cat <<EOF > $PREFIX/$lxc_config_file
lxc.utsname = $name
lxc.id_map = u 0 2000 10
lxc.id_map = g 0 1000 10
#lxc.cap.keep = sys_admin setuid
#lxc.cap.drop = sys_module mac_admin mac_override sys_time

lxc.tty = 1
lxc.pts = 1
lxc.rootfs = $lxc_rootfs_dir
lxc.mount = $lxc_config_dir/fstab
lxc.pivotdir = /tmp/lxc_putold

lxc.network.type = veth
lxc.network.flags = up
lxc.network.link = br0
lxc.network.hwaddr = 4a:49:43:49:79:be
lxc.network.ipv4 = 192.168.1.3/24
lxc.network.name = eth2
# lxc.network.ipv4.gateway = 192.168.1.1

lxc.network.type = veth
lxc.network.flags = up
lxc.network.link = br1
lxc.network.hwaddr = 4a:49:43:49:79:bc
lxc.network.ipv4 = 192.168.2.2/24
lxc.network.name = eth3
lxc.network.ipv4.gateway = 192.168.2.1

lxc.cgroup.devices.deny = a
# /dev/null and zero
lxc.cgroup.devices.allow = c 1:3 rwm
lxc.cgroup.devices.allow = c 1:5 rwm
# consoles
lxc.cgroup.devices.allow = c 5:1 rwm
lxc.cgroup.devices.allow = c 5:0 rwm
lxc.cgroup.devices.allow = c 4:0 rwm
lxc.cgroup.devices.allow = c 4:1 rwm
# /dev/{,u}random
lxc.cgroup.devices.allow = c 1:9 rwm
lxc.cgroup.devices.allow = c 1:8 rwm
lxc.cgroup.devices.allow = c 136:* rwm
lxc.cgroup.devices.allow = c 5:2 rwm
# hi_* 
lxc.cgroup.devices.allow = c 218:* rwm
# fb8
lxc.cgroup.devices.allow = c 29:* rwm
# others
lxc.cgroup.devices.allow = c 10:* rwm
EOF
	
	mkdir -p $PREFIX/usr/var/lib/lxc/$name
	cp $PREFIX/$lxc_config_file $PREFIX/usr/var/lib/lxc/$name
	chmod 644 $PREFIX/usr/var/lib/lxc/$name/config

	cat <<EOF > $PREFIX/$lxc_config_dir/fstab
proc            /home/$name/proc           proc    defaults        0       0
sysfs           /home/$name/sys            sysfs   defaults        0       0
tmp             /home/$name/tmp            tmpfs   nosuid,noexec,nodev,mode=1777
#/dev            /home/$name/dev            none    bind            0       0
#/lib            /home/$name/lib            none    bind            0       0
EOF
	chmod 644 $PREFIX/$lxc_config_dir/fstab

}

# create and deploy lxc config file for CA release 
install_lxc_rel_config()
{
	cat <<EOF > $PREFIX/$lxc_config_file
lxc.utsname = $name
lxc.id_map = u 0 2000 10
lxc.id_map = g 0 1000 10
#lxc.cap.keep = sys_admin setuid
#lxc.cap.drop = sys_module mac_admin mac_override sys_time

lxc.console = none

lxc.rootfs = $lxc_rootfs_dir
lxc.mount = $lxc_config_dir/fstab
lxc.pivotdir = /tmp/lxc_putold

lxc.network.type = veth
lxc.network.flags = up
lxc.network.link = br0
lxc.network.hwaddr = 4a:49:43:49:79:be
lxc.network.ipv4 = 192.168.1.3/24
lxc.network.name = eth2

lxc.network.type = veth
lxc.network.flags = up
lxc.network.link = br1
lxc.network.hwaddr = 4a:49:43:49:79:bc
lxc.network.ipv4 = 192.168.2.2/24
lxc.network.name = eth3
lxc.network.ipv4.gateway = 192.168.2.1

lxc.cgroup.devices.deny = a
# /dev/null and zero
lxc.cgroup.devices.allow = c 1:3 rwm
lxc.cgroup.devices.allow = c 1:5 rwm
# consoles
lxc.cgroup.devices.allow = c 5:1 rwm
lxc.cgroup.devices.allow = c 5:0 rwm
lxc.cgroup.devices.allow = c 4:0 rwm
lxc.cgroup.devices.allow = c 4:1 rwm
# /dev/{,u}random
lxc.cgroup.devices.allow = c 1:9 rwm
lxc.cgroup.devices.allow = c 1:8 rwm
lxc.cgroup.devices.allow = c 136:* rwm
lxc.cgroup.devices.allow = c 5:2 rwm
# hi_* 
lxc.cgroup.devices.allow = c 218:* rwm
# fb8
lxc.cgroup.devices.allow = c 29:* rwm
# others
lxc.cgroup.devices.allow = c 10:* rwm
EOF
	
	mkdir -p $PREFIX/usr/var/lib/lxc/$name
	cp $PREFIX/$lxc_config_file $PREFIX/usr/var/lib/lxc/$name
	chmod 644 $PREFIX/usr/var/lib/lxc/$name/config

	cat <<EOF > $PREFIX/$lxc_config_dir/fstab
proc            /home/$name/proc           proc    defaults        0       0
sysfs           /home/$name/sys            sysfs   defaults        0       0
tmp             /home/$name/tmp            tmpfs   nosuid,noexec,nodev,mode=1777
EOF
	chmod 644 $PREFIX/$lxc_config_dir/fstab

}

##################################################################################

lxc_config_dir=/opt/$name
lxc_config_file=$lxc_config_dir/config
lxc_rootfs_dir=/home/$name

install_fs_dir
install_busybox
install_app

if [ "$CFG_HI_ADVCA_FUNCTION" != "FINAL" ]; then
	install_dbg_fs_scripts
	install_lxc_dbg_config
else
	install_rel_fs_scripts
	install_lxc_rel_config
fi

